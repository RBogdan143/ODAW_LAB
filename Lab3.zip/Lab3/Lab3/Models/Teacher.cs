﻿using Lab3.Models.Base;

//Temă 3
namespace Lab3.Models
{
    public class Teacher: BaseEntity
    {
        public string? Name { get; set; }
        public int Age { get; set; }
        public double Salary { get; set; }
    }
}
