﻿namespace Lab4.Models.DTOs
{
    public class Principals_OfficeDTO
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
