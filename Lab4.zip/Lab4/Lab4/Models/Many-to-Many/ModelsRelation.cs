﻿namespace Lab4.Models.Many_to_Many
{
    public class ModelsRelation
    {
        public Guid ClassroomId { get; set; }
        public Classroom Classrooms { get; set; }

        public Guid LaboratoryId { get; set; }
        public Laboratory Laboratorys { get;set;}
    }
}
