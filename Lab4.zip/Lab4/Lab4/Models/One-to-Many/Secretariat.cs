﻿using Lab4.Models.Base;

namespace Lab4.Models.One_to_Many
{
    public class Secretariat: BaseEntity
    {
        public string Name { get; set; }

        // relation
        public Principals_Office Principals_Office { get; set; }

        public Guid Model1Id { get; set; }
    }
}
