﻿using Lab4.Models.Base;

namespace Lab4.Models.One_to_Many
{
    public class Principals_Office: BaseEntity
    {
        public string? Name { get; set; }

        // relation 
        public ICollection<Secretariat>? Secretariat { get; set; }
    }
}
