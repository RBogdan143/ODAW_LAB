﻿using Lab4.Models.Base;

namespace Lab4.Models.One_to_One
{
    public class Cafeteria: BaseEntity
    {
        public string? Name { get; set; }

        // relation
        public Food Food { get; set; }
    }
}
