﻿using Lab4.Models.Base;

namespace Lab4.Models.One_to_One
{
    public class Food: BaseEntity
    {
        public string? Name { get; set; }

        // relations
        public Cafeteria Cafeteria { get; set; }
        public Guid CafeteriaId { get; set; }  
    }
}
