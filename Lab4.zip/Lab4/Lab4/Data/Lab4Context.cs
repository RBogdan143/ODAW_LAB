﻿using Lab4.Models;
using Lab4.Models.Many_to_Many;
using Lab4.Models.One_to_Many;
using Lab4.Models.One_to_One;
using Microsoft.EntityFrameworkCore;

namespace Lab4.Data
{
    public class Lab4Context: DbContext
    {
        public DbSet<Student> Students { get; set; }    

        // One to Many
        public DbSet<Principals_Office> Principals_Office { get; set; }
        public DbSet<Secretariat> Secretariat { get; set; }


        // One to One
        public DbSet<Cafeteria> Cafeteria { get; set; }
        public DbSet<Food> Food { get; set; }

        // Many to Many

        public DbSet<Classroom> Classrooms { get; set; }
        public DbSet<Laboratory> Laboratorys { get; set; }
        public DbSet<ModelsRelation> ModelsRelations { get; set; }

        public Lab4Context(DbContextOptions<Lab4Context> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // One to Many
            modelBuilder.Entity<Principals_Office>()
                        .HasMany(m1 => m1.Secretariat)
                        .WithOne(m2 => m2.Principals_Office);


            //// another option
            //modelBuilder.Entity<Model2>()
            //            .HasOne(m2 => m2.Model1)
            //            .WithMany(m1 => m1.Models2);

            // One to One
            modelBuilder.Entity<Cafeteria>()
                .HasOne(m5 => m5.Food)
                .WithOne(m6 => m6.Cafeteria)
                .HasForeignKey<Food>(m6 => m6.CafeteriaId);

            
            // Many to Many
            modelBuilder.Entity<ModelsRelation>().HasKey(mr => new { mr.LaboratoryId, mr.ClassroomId });

            // One to many for m-m
            modelBuilder.Entity<ModelsRelation>()
                        .HasOne(mr => mr.Classrooms)
                        .WithMany(m3 => m3.ModelsRelations)
                        .HasForeignKey(mr => mr.ClassroomId);

            modelBuilder.Entity<ModelsRelation>()
                        .HasOne(mr => mr.Laboratorys)
                        .WithMany(m4 => m4.ModelsRelations)
                        .HasForeignKey(mr => mr.LaboratoryId);

            base.OnModelCreating(modelBuilder);
        }
    }
}
