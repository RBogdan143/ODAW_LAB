﻿using Lab4.Data;
using Lab4.Models.DTOs;
using Lab4.Models.One_to_Many;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Lab4.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DatabaseController : ControllerBase
    {
        private readonly Lab4Context _lab4Context;

        public DatabaseController(Lab4Context lab4Context)
        {
            _lab4Context = lab4Context;
        }

        [HttpGet("PO")]
        public async Task<IActionResult> GetModel1()
        {
            return Ok(await _lab4Context.Principals_Office.ToListAsync());
        }

        [HttpPost("POf")]
        public async Task<IActionResult> Create (Principals_OfficeDTO model1Dto)
        {
            var newModel1 = new Principals_Office
            {
                Id = Guid.NewGuid(),
                Name = model1Dto.Name
            };

            await _lab4Context.AddAsync(newModel1);
            await _lab4Context.SaveChangesAsync();

            return Ok(newModel1);
        }

        [HttpPost("update")]
        public async Task<IActionResult> Update(Principals_OfficeDTO model1Dto)
        {
            Principals_Office model1ById = await _lab4Context.Principals_Office.FirstOrDefaultAsync(x => x.Id == model1Dto.Id);
            if (model1ById == null)
            {
                return BadRequest("Object does not exist");
            }

            model1ById.Name = model1Dto.Name;
            _lab4Context.Update(model1ById);
            await _lab4Context.SaveChangesAsync();
            
            return Ok(model1ById);
        }
    }
}
